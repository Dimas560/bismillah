<?php
  header("location: auth");
?>